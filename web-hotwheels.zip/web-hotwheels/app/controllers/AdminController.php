<?php
class AdminController {
    // Khai báo các thuộc tính để chứa các model
    private $productModel;
    private $orderModel;
    private $categoryModel;
    private $userModel;
    private $voucherModel;
    // private $pageModel; // Sẽ dùng cho CMS

    public function __construct() {
        // Bảo vệ: Chỉ admin mới có quyền truy cập vào controller này
        if (!Session::isAdmin()) {
            // Nếu không phải admin, chuyển hướng về trang đăng nhập
            header('location: /web-hotwheels/auth/login');
            exit();
        }

        // Khởi tạo các model để sử dụng trong controller
        $this->productModel = new Product();
        $this->orderModel = new Order();
        $this->categoryModel = new Category();
        $this->userModel = new User();
        $this->voucherModel = new Voucher();
        // $this->pageModel = new Page(); // Sẽ dùng cho CMS
    }

    //================================================================
    // DASHBOARD
    //================================================================

    /**
     * Hiển thị trang dashboard chính của admin với các số liệu thống kê.
     */
    public function dashboard() {
        // Lấy dữ liệu thống kê từ model
        $stats = $this->orderModel->getStatistics();
        // Tải view của dashboard và truyền dữ liệu thống kê vào
        require_once 'app/views/admin/dashboard.php';
    }

    //================================================================
    // PRODUCT MANAGEMENT (Quản lý Sản phẩm)
    //================================================================

    /**
     * Hiển thị danh sách tất cả sản phẩm.
     */
    public function products() {
    // Gọi đến phương thức mới dành riêng cho admin
    $products = $this->productModel->findAllForAdmin();
    require_once 'app/views/admin/products/index.php';
}

    /**
     * Hiển thị form và xử lý việc tạo sản phẩm mới.
     */
    public function createProduct() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Lọc và làm sạch dữ liệu đầu vào
            $data = [
                'name' => trim($_POST['name']),
                'description' => trim($_POST['description']),
                'price' => trim($_POST['price']),
                'stock_quantity' => trim($_POST['stock_quantity']),
                'category_id' => trim($_POST['category_id']),
                'sku' => 'HW-' . rand(1000, 9999), // Tạo SKU đơn giản
                'slug' => strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $_POST['name'])))
            ];

            // Lưu sản phẩm vào DB và lấy ID sản phẩm vừa tạo
            $productId = $this->productModel->create($data);

            if ($productId && isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] == 0) {
            $targetDir = "public/uploads/";
            // Tạo tên file duy nhất để tránh bị ghi đè
            $fileName = time() . '-' . basename($_FILES["thumbnail"]["name"]);
            $targetFilePath = $targetDir . $fileName;

            if(move_uploaded_file($_FILES["thumbnail"]["tmp_name"], $targetFilePath)){
                // Nếu upload thành công, thêm đường dẫn ảnh vào DB
                $this->productModel->addImage($productId, $targetFilePath, true); // true nghĩa là ảnh thumbnail
            }
        }
        header('location: /web-hotwheels/admin/products');
            exit();
        } else {
            // Lấy danh sách category để hiển thị trong form
            $categories = $this->categoryModel->findAll();
            require_once 'app/views/admin/products/create.php';
        }
    }

    /**
     * Hiển thị form và xử lý việc cập nhật thông tin sản phẩm.
     * @param int $id ID của sản phẩm cần sửa
     */
    public function editProduct($id) {
    // Xử lý khi người dùng nhấn nút "Lưu Thay đổi" (phương thức POST)
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // 1. Chuẩn bị dữ liệu text từ form
        $data = [
            'id' => $id,
            'name' => trim($_POST['name']),
            'description' => trim($_POST['description']),
            'price' => trim($_POST['price']),
            'stock_quantity' => trim($_POST['stock_quantity']),
            'category_id' => trim($_POST['category_id']),
        ];

        // 2. Cập nhật thông tin text của sản phẩm
        $updateSuccess = $this->productModel->update($data);

        // 3. Nếu có file ảnh mới được tải lên, xử lý file ảnh
        if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] == 0) {
            $targetDir = "public/uploads/";
            // Tạo tên file duy nhất để tránh trùng lặp
            $fileName = time() . '-' . basename($_FILES["thumbnail"]["name"]);
            $targetFilePath = $targetDir . $fileName;

            // Di chuyển file đã upload vào thư mục public/uploads
            if(move_uploaded_file($_FILES["thumbnail"]["tmp_name"], $targetFilePath)){
                 // Gọi đến phương thức mới trong Model để cập nhật ảnh trong database
                $this->productModel->updateThumbnail($id, $targetFilePath);
            }
        }
        
        // 4. Sau khi hoàn tất, chuyển hướng về trang danh sách sản phẩm
        header('location: /web-hotwheels/admin/products');
        exit(); // Dừng kịch bản sau khi chuyển hướng

    } else {
        // Xử lý khi người dùng mới truy cập trang sửa (phương thức GET)
        $product = $this->productModel->findById($id);
        $categories = $this->categoryModel->findAll();
        require_once 'app/views/admin/products/edit.php';
    }
}

    /**
     * Xử lý việc xóa một sản phẩm.
     * @param int $id ID của sản phẩm cần xóa
     */
    public function deleteProduct($id) {
        if ($this->productModel->delete($id)) {
            header('location: /web-hotwheels/admin/products');
        } else {
            die('Xóa sản phẩm thất bại.');
        }
    }

    //================================================================
    // CATEGORY MANAGEMENT (Quản lý Danh mục)
    //================================================================

    /**
     * Hiển thị danh sách các danh mục sản phẩm.
     */
    public function categories() {
        $categories = $this->categoryModel->findAll();
        require_once 'app/views/admin/categories/index.php';
    }
    
    /**
     * Hiển thị form và xử lý việc tạo danh mục mới.
     */
    public function createCategory() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $data = [
                'name' => trim($_POST['name']),
                'description' => trim($_POST['description']),
                'slug' => strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $_POST['name'])))
            ];
            if ($this->categoryModel->create($data)) {
                header('location: /web-hotwheels/admin/categories');
            } else {
                die('Thêm danh mục thất bại.');
            }
        } else {
            require_once 'app/views/admin/categories/create.php';
        }
    }

    //================================================================
    // ORDER MANAGEMENT (Quản lý Đơn hàng)
    //================================================================

    /**
     * Hiển thị danh sách tất cả đơn hàng.
     */
    public function orders() {
        $orders = $this->orderModel->findAll();
        require_once 'app/views/admin/orders/index.php';
    }

    /**
     * Xem chi tiết một đơn hàng.
     * @param int $id ID của đơn hàng cần xem
     */
    public function viewOrder($id) {
        $order = $this->orderModel->findByIdWithDetails($id);
        if ($order) {
            require_once 'app/views/admin/orders/show.php';
        } else {
            die('Không tìm thấy đơn hàng.');
        }
    }

    /**
     * Cập nhật trạng thái của một đơn hàng.
     * @param int $id ID của đơn hàng cần cập nhật
     */
    public function updateOrderStatus($id) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $status = $_POST['status'];
            if($this->orderModel->updateStatus($id, $status)) {
                header('location: /web-hotwheels/admin/viewOrder/' . $id);
            } else {
                die('Cập nhật trạng thái thất bại.');
            }
        }
    }

    //================================================================
    // CUSTOMER MANAGEMENT (Quản lý Khách hàng)
    //================================================================
    
    /**
     * Hiển thị danh sách tất cả người dùng (khách hàng).
     */
    public function customers() {
        $customers = $this->userModel->findAll();
        require_once 'app/views/admin/customers/index.php';
    }

    public function editCategory($id) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Xử lý dữ liệu được gửi lên từ form sửa
        $data = [
            'id' => $id,
            'name' => trim($_POST['name']),
            'description' => trim($_POST['description']),
            // Tạo slug mới từ tên mới
            'slug' => strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $_POST['name'])))
        ];

        if ($this->categoryModel->update($data)) {
            // Nếu cập nhật thành công, chuyển hướng về trang danh sách
            header('location: /web-hotwheels/admin/categories');
        } else {
            die('Cập nhật danh mục thất bại.');
        }
    } else {
        // Lấy thông tin danh mục hiện tại để hiển thị trên form
        $category = $this->categoryModel->findById($id);
        if ($category) {
            // Tải file view và truyền dữ liệu của danh mục vào
            require_once 'app/views/admin/categories/edit.php';
        } else {
            // Nếu không tìm thấy danh mục, quay về trang danh sách
            header('location: /web-hotwheels/admin/categories');
        }
    }
}


    // Thêm 2 phương thức này vào AdminController
public function vouchers() {
    $vouchers = $this->voucherModel->findAll();
    require_once 'app/views/admin/vouchers/index.php';
}

public function createVoucher() {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $data = [
            'code' => trim($_POST['code']),
            'discount_type' => $_POST['discount_type'],
            'discount_value' => trim($_POST['discount_value']),
            'max_usage' => trim($_POST['max_usage']),
            'start_date' => $_POST['start_date'],
            'end_date' => $_POST['end_date'],
        ];
        if ($this->voucherModel->create($data)) {
            header('location: /web-hotwheels/admin/vouchers');
        } else {
            die('Tạo voucher thất bại.');
        }
    } else {
        require_once 'app/views/admin/vouchers/create.php';
    }
}
}