<?php
class AuthController {
    private $userModel;

    public function __construct() {
        $this->userModel = new User();
    }

    // Hiển thị form đăng nhập
    public function login() {
        require_once 'app/views/auth/login.php';
    }

    // Hiển thị form đăng ký
    public function register() {
        require_once 'app/views/auth/register.php';
    }

    // Xử lý đăng ký
    public function handleRegister() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            $data = [
                'full_name' => trim($_POST['full_name']),
                'email' => trim($_POST['email']),
                'password' => trim($_POST['password']),
                'confirm_password' => trim($_POST['confirm_password']),
                'errors' => []
            ];

            if ($this->userModel->findUserByEmail($data['email'])) {
                $data['errors']['email'] = 'Email đã được sử dụng.';
            }
            if ($data['password'] != $data['confirm_password']) {
                $data['errors']['password'] = 'Mật khẩu không khớp.';
            }

            if (empty($data['errors'])) {
                $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
                if ($this->userModel->register($data)) {
                    header('location: /web-hotwheels/auth/login');
                } else {
                    die('Something went wrong.');
                }
            } else {
                // Tải lại view với lỗi
                require_once 'app/views/auth/register.php';
            }
        }
    }

    // Xử lý đăng nhập
    public function handleLogin() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $email = $_POST['email'];
            $password = $_POST['password'];

            $loggedInUser = $this->userModel->login($email, $password);

            if ($loggedInUser) {
                Session::createUserSession($loggedInUser);
                if (Session::isAdmin()) {
                    header('location: /web-hotwheels/admin/dashboard');
                } else {
                    header('location: /web-hotwheels/home');
                }
            } else {
                // Xử lý lỗi đăng nhập
                $error = "Email hoặc mật khẩu không đúng.";
                require_once 'app/views/auth/login.php';
            }
        }
    }
    
    // Đăng xuất
    public function logout() {
        Session::destroyUserSession();
        header('location: /web-hotwheels/auth/login');
    }


    // Hiển thị form yêu cầu reset
    public function forgotPassword() {
        require_once 'app/views/auth/forgot_password.php';
    }

    // Xử lý yêu cầu reset
    public function handleForgotPassword() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $email = $_POST['email'];
            if ($this->userModel->findUserByEmail($email)) {
                $token = $this->userModel->createPasswordResetToken($email);
                // GIẢ LẬP GỬI MAIL: Hiển thị link ra màn hình
                $reset_link = "http://localhost:8888/web-hotwheels/auth/resetPassword?token=" . $token;
                require 'app/views/auth/reset_link_sent.php';
            } else {
                $error = "Email không tồn tại trong hệ thống.";
                require 'app/views/auth/forgot_password.php';
            }
        }
    }

    // Hiển thị form nhập mật khẩu mới
    public function resetPassword() {
        $token = $_GET['token'] ?? '';
        $user = $this->userModel->getUserByResetToken($token);
        if ($user) {
            require 'app/views/auth/reset_password_form.php';
        } else {
            die("Link không hợp lệ hoặc đã hết hạn. Vui lòng thử lại.");
        }
    }

    // Xử lý việc tạo mật khẩu mới
    public function handleResetPassword() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $token = $_POST['token'];
            $password = $_POST['password'];
            $confirm_password = $_POST['confirm_password'];

            $user = $this->userModel->getUserByResetToken($token);
            if (!$user) {
                die("Link không hợp lệ hoặc đã hết hạn.");
            }
            if ($password !== $confirm_password) {
                $error = "Mật khẩu không khớp.";
                require 'app/views/auth/reset_password_form.php';
                return;
            }

            if ($this->userModel->updatePassword($user->id, $password)) {
                $this->userModel->deletePasswordResetToken($user->email);
                // Chuyển hướng đến trang đăng nhập với thông báo thành công
                header('location: /web-hotwheels/auth/login?status=reset_success');
            } else {
                die("Có lỗi xảy ra, không thể cập nhật mật khẩu.");
            }
        }
    }
}