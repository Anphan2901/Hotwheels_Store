<?php
class CartController {
    private $productModel;
    private $voucherModel;

    public function __construct() {
        $this->productModel = new Product();
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
        $this->voucherModel = new Voucher();
    }

    // Hiển thị giỏ hàng
    public function index() {
        $cart = $_SESSION['cart'];
        $voucher = $_SESSION['voucher'] ?? null;
        require_once 'app/views/cart/index.php';
    }

    // Thêm sản phẩm vào giỏ
    public function add($id) {
        $product = $this->productModel->findById($id);
        if ($product) {
            if (isset($_SESSION['cart'][$id])) {
                $_SESSION['cart'][$id]['quantity']++;
            } else {
                $_SESSION['cart'][$id] = [
                    'id' => $product->id,
                    'name' => $product->name,
                    'price' => $product->price,
                    'quantity' => 1
                    //'image' => $product->image_url // Cần lấy ảnh thumbnail
                ];
            }
        }
        header('location: /web-hotwheels/cart');
    }
    
    // Xóa sản phẩm khỏi giỏ
    public function remove($id) {
        if(isset($_SESSION['cart'][$id])) {
            unset($_SESSION['cart'][$id]);
        }
         header('location: /web-hotwheels/cart');
    }
    public function applyVoucher() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $code = trim($_POST['code']);
            $voucher = $this->voucherModel->findByCode($code);
            
            if ($voucher) {
                $_SESSION['voucher'] = (array)$voucher;
            } else {
                $_SESSION['voucher_error'] = "Mã giảm giá không hợp lệ hoặc đã hết hạn.";
            }
            header('location: /web-hotwheels/cart');
        }
    }
    public function removeVoucher() {
        unset($_SESSION['voucher']);
        unset($_SESSION['voucher_error']);
        header('location: /web-hotwheels/cart');
    }   

}