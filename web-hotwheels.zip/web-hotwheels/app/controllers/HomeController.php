<?php
class HomeController {
    private $productModel;

    public function __construct() {
        $this->productModel = new Product();
    }

    public function index() {
    // Lấy các tham số tìm kiếm, lọc, sắp xếp từ URL
    $params = [
        'keyword' => isset($_GET['search']) ? trim($_GET['search']) : '',
        'category_id' => isset($_GET['category']) ? trim($_GET['category']) : '',
        'sort' => isset($_GET['sort']) ? trim($_GET['sort']) : 'default'
    ];
    // Lấy danh sách sản phẩm đã lọc
    $products = $this->productModel->searchAndFilter($params);

    // === PHẦN SỬA LỖI - LẤY THUMBNAIL CHO MỖI SẢN PHẨM ===
    // Nếu có sản phẩm, lặp qua từng cái để lấy ảnh thumbnail
    if (!empty($products)) {
        foreach ($products as $product) {
            // Gọi đến Model để lấy ảnh và gán vào một thuộc tính mới là 'thumbnail'
            $product->thumbnail = $this->productModel->getThumb($product->id);
        }
    }
    // === KẾT THÚC PHẦN SỬA LỖI ===

    // Lấy danh sách danh mục và tải view
    $categories = (new Category())->findAll();
    require_once 'app/views/home/index.php';
}

    public function sale() {
        $products = $this->productModel->findSaleProducts();
        $categories = (new Category())->findAll();
        // Chúng ta có thể tái sử dụng view của trang chủ để hiển thị
        require_once 'app/views/home/index.php';
    }

    // Thêm phương thức mới cho trang Recommended
    public function recommended() {
        $products = $this->productModel->findRecommendedProducts();
        $categories = (new Category())->findAll();
        // Tái sử dụng view của trang chủ
        require_once 'app/views/home/index.php';
    }
}