<?php
class OrderController {
    private $orderModel;



    public function __construct() {
        if (!Session::isLoggedIn()) {
            header('location: /web-hotwheels/auth/login');
            exit();
        }
        $this->orderModel = new Order();
    }

    public function index() {
    // Lấy giỏ hàng từ session
    $cart = $_SESSION['cart'] ?? [];

    // Nếu giỏ hàng rỗng, chuyển về trang giỏ hàng
    if (empty($cart)) {
        header('location: /web-hotwheels/cart');
        exit();
    }

    // Lấy thông tin voucher từ session (nếu có)
    $voucher = $_SESSION['voucher'] ?? null;

    // Tải view và truyền cả $cart và $voucher vào
    require_once 'app/views/checkout/index.php';
}

    public function placeOrder() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_SESSION['cart'])) {
            
            // Tính toán lại tổng tiền và lấy ID voucher từ session
            $totalAmount = 0;
            foreach($_SESSION['cart'] as $item) {
                $totalAmount += $item['price'] * $item['quantity'];
            }

            $voucherId = null; // Mặc định không có voucher
            if (isset($_SESSION['voucher'])) {
                $voucher = $_SESSION['voucher'];
                $discount = ($voucher['discount_type'] == 'fixed') ? $voucher['discount_value'] : ($totalAmount * $voucher['discount_value']) / 100;
                $totalAmount -= $discount;
                $voucherId = $voucher['id'];
            }

            // Chuẩn bị dữ liệu để tạo đơn hàng
            $data = [
                'user_id' => $_SESSION['user_id'],
                'shipping_address' => trim($_POST['address']),
                'payment_method' => 'cod',
                'total_amount' => $totalAmount,
                'order_code' => 'HD' . time(),
                'cart_items' => $_SESSION['cart'],
                'voucher_id' => $voucherId // <-- Truyền ID voucher vào data
            ];

            if ($this->orderModel->createOrder($data)) {
                // Nếu đặt hàng thành công, xóa giỏ hàng và voucher khỏi session
                unset($_SESSION['cart']);
                unset($_SESSION['voucher']); 
                
                header('location: /web-hotwheels/order/success');
                exit();
            } else {
                die('Đặt hàng thất bại do có lỗi xảy ra, vui lòng thử lại.');
            }
        } else {
            header('location: /web-hotwheels/cart');
            exit();
        }
    }

    public function success() {
        require_once 'app/views/checkout/success.php';
    }
}