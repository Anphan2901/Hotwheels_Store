<?php
class ProductController {
    private $productModel;
    private $reviewModel; // Thêm

    public function __construct() {
        $this->productModel = new Product();
        $this->reviewModel = new Review(); // Khởi tạo
    }

    public function show($id) {
        // Lấy thông tin chính của sản phẩm
        $product = $this->productModel->findById($id);

        if ($product) {
            // Lấy tất cả hình ảnh của sản phẩm
            $product->images = $this->productModel->findImagesByProductId($id);
            // Lấy tất cả đánh giá của sản phẩm
            $reviews = $this->reviewModel->findByProductId($id);

            // Tải file view và truyền dữ liệu sang
            require_once 'app/views/products/show.php';
        } else {
            // Nếu không tìm thấy sản phẩm, hiển thị thông báo
            echo "404 - Sản phẩm không tồn tại.";
        }
    }
    
    public function addReview($productId) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && Session::isLoggedIn()) {
            $data = [
                'product_id' => $productId,
                'user_id' => $_SESSION['user_id'],
                'rating' => $_POST['rating'],
                'comment' => trim($_POST['comment'])
            ];
            if ($this->reviewModel->create($data)) {
                header('location: /web-hotwheels/product/show/' . $productId);
            }
        } else {
            header('location: /web-hotwheels/auth/login');
        }
    }
}