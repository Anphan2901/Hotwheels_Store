<?php
class UserController {
    private $orderModel;
    private $userModel;
    private $wishlistModel;

    public function __construct() {
        if (!Session::isLoggedIn()) {
            header('location: /web-hotwheels/auth/login');
            exit();
        }
        $this->orderModel = new Order();
        $this->wishlistModel = new Wishlist();
        $this->userModel = new User();
    }

    public function orders() {
        $orders = $this->orderModel->findOrdersByUserId($_SESSION['user_id']);
        require_once 'app/views/user/orders.php';
    }

    public function profile() {
        $user = $this->userModel->findById($_SESSION['user_id']);
        require_once 'app/views/user/profile.php';
    }
    public function addToWishlist($productId) {
        if ($this->wishlistModel->add($_SESSION['user_id'], $productId)) {
            header('Location: ' . $_SERVER['HTTP_REFERER']);
        }
    }

    public function wishlist() {
    // Dùng Wishlist model để lấy danh sách sản phẩm yêu thích của user hiện tại
    $wishlistItems = $this->wishlistModel->findByUserId($_SESSION['user_id']);

    // Tải file view và truyền dữ liệu sản phẩm vào đó
    require_once 'app/views/user/wishlist.php';
}

    public function updateProfile() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $data = [
                'id' => $_SESSION['user_id'],
                'full_name' => trim($_POST['full_name']),
                'phone_number' => trim($_POST['phone_number'])
            ];
            if ($this->userModel->updateProfile($data)) {
                $_SESSION['user_name'] = $data['full_name'];
                header('location: /web-hotwheels/user/profile');
            } else {
                die('Cập nhật thất bại.');
            }
        }
    }
}