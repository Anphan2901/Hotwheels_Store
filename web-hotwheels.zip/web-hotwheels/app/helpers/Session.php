<?php
class Session {
    /**
     * Tạo session cho người dùng sau khi đăng nhập thành công.
     * @param object $user Đối tượng user chứa thông tin từ database.
     */
    public static function createUserSession($user) {
        $_SESSION['user_id'] = $user->id;
        $_SESSION['user_email'] = $user->email;
        $_SESSION['user_name'] = $user->full_name;
        $_SESSION['user_role'] = $user->role;
    }

    /**
     * Hủy toàn bộ session khi người dùng đăng xuất.
     */
    public static function destroyUserSession() {
        unset($_SESSION['user_id']);
        unset($_SESSION['user_email']);
        unset($_SESSION['user_name']);
        unset($_SESSION['user_role']);
        // Cân nhắc session_destroy() nếu bạn muốn hủy toàn bộ session
        // session_destroy();
    }

    /**
     * Kiểm tra xem người dùng đã đăng nhập hay chưa.
     * @return bool True nếu đã đăng nhập, False nếu chưa.
     */
    public static function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }

    /**
     * Kiểm tra xem người dùng có phải là admin không.
     * @return bool True nếu là admin, False nếu không phải.
     */
    public static function isAdmin() {
        return (self::isLoggedIn() && isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin');
    }
}