<?php
class Order {
    private $db;

    public function __construct() {
        $this->db = new Database;
    }

    public function createOrder($data) {
        try {
            // Bắt đầu một transaction để đảm bảo tất cả các lệnh đều thành công
            // hoặc không có lệnh nào được thực thi cả.
            $this->db->beginTransaction();

            // 1. Chèn thông tin vào bảng `orders`
            $this->db->query('INSERT INTO orders (user_id, order_code, total_amount, shipping_address, payment_method) VALUES (:user_id, :order_code, :total_amount, :shipping_address, :payment_method)');
            $this->db->bind(':user_id', $data['user_id']);
            $this->db->bind(':order_code', $data['order_code']);
            $this->db->bind(':total_amount', $data['total_amount']);
            $this->db->bind(':shipping_address', $data['shipping_address']);
            $this->db->bind(':payment_method', $data['payment_method']);
            $this->db->execute();
            $orderId = $this->db->lastInsertId();

            // 2. Chèn các sản phẩm của đơn hàng vào bảng `order_items`
            foreach ($data['cart_items'] as $item) {
                $this->db->query('INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (:order_id, :product_id, :quantity, :price)');
                $this->db->bind(':order_id', $orderId);
                $this->db->bind(':product_id', $item['id']);
                $this->db->bind(':quantity', $item['quantity']);
                $this->db->bind(':price', $item['price']);
                $this->db->execute();
                
                // Trừ số lượng tồn kho
                $this->db->query('UPDATE products SET stock_quantity = stock_quantity - :quantity WHERE id = :product_id');
                $this->db->bind(':quantity', $item['quantity']);
                $this->db->bind(':product_id', $item['id']);
                $this->db->execute();
            }

            // 3. === PHẦN SỬA LỖI - CẬP NHẬT VOUCHER ===
            if (!empty($data['voucher_id'])) {
                // Thêm một record vào bảng order_vouchers để biết đơn hàng này đã dùng voucher nào
                $this->db->query('INSERT INTO order_vouchers (order_id, voucher_id) VALUES (:order_id, :voucher_id)');
                $this->db->bind(':order_id', $orderId);
                $this->db->bind(':voucher_id', $data['voucher_id']);
                $this->db->execute();

                // Tăng số lượt đã sử dụng của voucher lên 1
                $this->db->query('UPDATE vouchers SET current_usage = current_usage + 1 WHERE id = :voucher_id');
                $this->db->bind(':voucher_id', $data['voucher_id']);
                $this->db->execute();
            }

            // Nếu tất cả các lệnh trên thành công, xác nhận transaction
            return $this->db->commit();

        } catch (Exception $e) {
            // Nếu có bất kỳ lỗi nào, hủy bỏ tất cả các thay đổi
            $this->db->rollBack();
            // Ghi lại lỗi để gỡ rối (tùy chọn)
            // error_log($e->getMessage());
            return false;
        }
    }
    
    // Thêm các hàm tìm kiếm đơn hàng
    public function findOrdersByUserId($userId) {
        $this->db->query("SELECT * FROM orders WHERE user_id = :user_id ORDER BY created_at DESC");
        $this->db->bind(':user_id', $userId);
        return $this->db->resultSet();
    }

    public function findAll() {
        $this->db->query("SELECT o.*, u.full_name as customer_name FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC");
        return $this->db->resultSet();
    }
    

   public function findByIdWithDetails($id) {
    // Thêm JOIN với bảng users để lấy full_name và email
    $this->db->query("
        SELECT o.*, u.full_name, u.email
        FROM orders o
        JOIN users u ON o.user_id = u.id
        WHERE o.id = :id
    ");
    $this->db->bind(':id', $id);
    $order = $this->db->single();

    if ($order) {
        $this->db->query("SELECT oi.*, p.name as product_name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = :id");
        $this->db->bind(':id', $id);
        $order->items = $this->db->resultSet();
    }
    return $order;
}

    public function updateStatus($id, $status) {
        $this->db->query('UPDATE orders SET status = :status WHERE id = :id');
        $this->db->bind(':id', $id);
        $this->db->bind(':status', $status);
        return $this->db->execute();
    }

    public function getStatistics() {
        // Lấy tổng doanh thu từ các đơn hàng đã hoàn thành
        $this->db->query("SELECT SUM(total_amount) as total_revenue FROM orders WHERE status = 'completed'");
        $total_revenue = $this->db->single()->total_revenue ?? 0;

        // Lấy tổng số đơn hàng
        $this->db->query("SELECT COUNT(id) as total_orders FROM orders");
        $total_orders = $this->db->single()->total_orders ?? 0;

        // Lấy tổng số khách hàng
        $this->db->query("SELECT COUNT(id) as total_customers FROM users WHERE role = 'customer'");
        $total_customers = $this->db->single()->total_customers ?? 0;
        
        return [
            'total_revenue' => $total_revenue,
            'total_orders' => $total_orders,
            'total_customers' => $total_customers,
        ];
    }
}