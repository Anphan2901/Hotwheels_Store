<?php
class Product {
    private $db;

    public function __construct() {
        $this->db = new Database;
    }

   public function findAll() {
    // Thêm điều kiện "WHERE p.is_active = TRUE" để chỉ lấy sản phẩm đang hoạt động
    $this->db->query("
        SELECT p.*, c.name as category_name 
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.id 
        WHERE p.is_active = TRUE
        ORDER BY p.created_at DESC
    ");
    return $this->db->resultSet();
}

    public function findById($id) {
        $this->db->query("SELECT * FROM products WHERE id = :id");
        $this->db->bind(':id', $id);
        return $this->db->single();
    }
    
    // Thêm phương thức mới
    public function create($data) {
        $this->db->query('INSERT INTO products (name, slug, sku, description, price, stock_quantity, category_id) VALUES (:name, :slug, :sku, :description, :price, :stock_quantity, :category_id)');
        // Bind data
        $this->db->bind(':name', $data['name']);
        $this->db->bind(':slug', $data['slug']);
        $this->db->bind(':sku', $data['sku']);
        $this->db->bind(':description', $data['description']);
        $this->db->bind(':price', $data['price']);
        $this->db->bind(':stock_quantity', $data['stock_quantity']);
        $this->db->bind(':category_id', $data['category_id']);

        if ($this->db->execute()) {
            return $this->db->lastInsertId();
        }
        return false;
    }

    public function addImage($product_id, $image_url, $is_thumbnail = false) {
        $this->db->query('INSERT INTO product_images (product_id, image_url, is_thumbnail) VALUES (:product_id, :image_url, :is_thumbnail)');
        $this->db->bind(':product_id', $product_id);
        $this->db->bind(':image_url', $image_url);
        $this->db->bind(':is_thumbnail', $is_thumbnail);
        return $this->db->execute();
    }
    
    public function update($data) {
        $this->db->query('UPDATE products SET name = :name, description = :description, price = :price, stock_quantity = :stock_quantity, category_id = :category_id WHERE id = :id');
        // Bind data
        $this->db->bind(':id', $data['id']);
        $this->db->bind(':name', $data['name']);
        $this->db->bind(':description', $data['description']);
        $this->db->bind(':price', $data['price']);
        $this->db->bind(':stock_quantity', $data['stock_quantity']);
        $this->db->bind(':category_id', $data['category_id']);

        return $this->db->execute();
    }

    public function delete($id) {
    $this->db->query('UPDATE products SET is_active = FALSE WHERE id = :id');
    $this->db->bind(':id', $id);

    if ($this->db->execute()) {
        return true;
    } else {
        return false;
    }
}

    // public function getThumb($productId) {
    //     $this->db->query('SELECT image_url FROM product_images WHERE product_id = :id AND is_thumbnail = 1 LIMIT 1');
    //     $this->db->bind(':id', $productId);
    //     $row = $this->db->single();
    //     return $row ? $row->image_url : null;
    // }

    public function getThumb($productId) {
    $this->db->query('SELECT image_url FROM product_images WHERE product_id = :id AND is_thumbnail = 1 LIMIT 1');
    $this->db->bind(':id', $productId);
    $row = $this->db->single();
    // Nếu có kết quả thì trả về đường dẫn ảnh, nếu không thì trả về null
    return $row ? $row->image_url : null;
}

    

    public function search($keyword) {
        $this->db->query("SELECT * FROM products WHERE name LIKE :keyword OR description LIKE :keyword");
        $this->db->bind(':keyword', '%' . $keyword . '%');
        return $this->db->resultSet();
    }

    public function searchAndFilter($params = []) {
    $sql = "SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.is_active = TRUE";

    // Thêm điều kiện tìm kiếm và lọc (như cũ)
    if (!empty($params['keyword'])) {
        $sql .= " AND (p.name LIKE :keyword OR p.description LIKE :keyword)";
    }
    if (!empty($params['category_id'])) {
        $sql .= " AND p.category_id = :category_id";
    }

    // === PHẦN MỚI: XỬ LÝ SẮP XẾP ===
    // Mặc định sắp xếp theo sản phẩm mới nhất
    $orderBy = " ORDER BY p.created_at DESC";

    // Kiểm tra và áp dụng các lựa chọn sắp xếp khác
    if (!empty($params['sort'])) {
        switch ($params['sort']) {
            case 'price_asc':
                $orderBy = " ORDER BY p.price ASC";
                break;
            case 'price_desc':
                $orderBy = " ORDER BY p.price DESC";
                break;
            case 'name_asc':
                $orderBy = " ORDER BY p.name ASC";
                break;
            case 'name_desc':
                $orderBy = " ORDER BY p.name DESC";
                break;
        }
    }
    // Nối mệnh đề ORDER BY vào câu lệnh SQL cuối cùng
    $sql .= $orderBy;
    // === KẾT THÚC PHẦN MỚI ===

    $this->db->query($sql);

    // Bind các tham số (như cũ)
    if (!empty($params['keyword'])) {
        $this->db->bind(':keyword', '%' . $params['keyword'] . '%');
    }
    if (!empty($params['category_id'])) {
        $this->db->bind(':category_id', $params['category_id']);
    }

    return $this->db->resultSet();
}

    // Thêm phương thức này vào trong class Product
    public function findSaleProducts() {
        // Lấy sản phẩm có giá sale và đang được bán
        $this->db->query("SELECT * FROM products WHERE sale_price IS NOT NULL AND sale_price > 0 AND is_active = TRUE ORDER BY created_at DESC");
        return $this->db->resultSet();
    }

    // Thêm phương thức này vào trong class Product
    public function findRecommendedProducts() {
        // Lấy sản phẩm được đánh dấu recommended và đang được bán
        $this->db->query("SELECT * FROM products WHERE is_recommended = TRUE AND is_active = TRUE ORDER BY created_at DESC");
        return $this->db->resultSet();
    }

    public function findImagesByProductId($id) {
    $this->db->query("SELECT * FROM product_images WHERE product_id = :id");
    $this->db->bind(':id', $id);
    return $this->db->resultSet();
}

    // Phương thức này lấy TẤT CẢ sản phẩm, không lọc theo is_active
    public function findAllForAdmin() {
        $this->db->query("
        SELECT p.*, c.name as category_name 
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.id 
        ORDER BY p.created_at DESC
    ");
    return $this->db->resultSet();
}


/**
     * Cập nhật hoặc thêm mới ảnh đại diện (thumbnail) cho sản phẩm.
     * Nó sẽ xóa ảnh thumbnail cũ trước khi thêm ảnh mới để đảm bảo mỗi sản phẩm chỉ có 1 thumbnail.
     * @param int $productId ID của sản phẩm
     * @param string $imageUrl Đường dẫn của ảnh mới
     */
    public function updateThumbnail($productId, $imageUrl) {
        // Bước 1: Xóa tất cả các ảnh đang được đánh dấu là thumbnail của sản phẩm này
        $this->db->query("DELETE FROM product_images WHERE product_id = :product_id AND is_thumbnail = TRUE");
        $this->db->bind(':product_id', $productId);
        $this->db->execute();

        // Bước 2: Thêm ảnh mới vào và đánh dấu nó là thumbnail
        $this->db->query("INSERT INTO product_images (product_id, image_url, is_thumbnail) VALUES (:product_id, :image_url, TRUE)");
        $this->db->bind(':product_id', $productId);
        $this->db->bind(':image_url', $imageUrl);
        
        return $this->db->execute();
    }
}