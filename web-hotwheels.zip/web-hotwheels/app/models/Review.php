<?php
class Review {
    private $db;
    public function __construct() { $this->db = new Database; }

    public function findByProductId($id) {
        $this->db->query("SELECT r.*, u.full_name FROM reviews r JOIN users u ON r.user_id = u.id WHERE r.product_id = :id ORDER BY r.created_at DESC");
        $this->db->bind(':id', $id);
        return $this->db->resultSet();
    }

    public function create($data) {
        $this->db->query("INSERT INTO reviews (product_id, user_id, rating, comment) VALUES (:product_id, :user_id, :rating, :comment)");
        $this->db->bind(':product_id', $data['product_id']);
        $this->db->bind(':user_id', $data['user_id']);
        $this->db->bind(':rating', $data['rating']);
        $this->db->bind(':comment', $data['comment']);
        return $this->db->execute();
    }
}