<?php
class User {
    private $db;

    public function __construct() {
        $this->db = new Database;
    }

    // // Tìm user bằng email
    // public function findUserByEmail($email) {
    //     $this->db->query('SELECT * FROM users WHERE email = :email');
    //     $this->db->bind(':email', $email);
    //     $row = $this->db->single();
    //     return $this->db->rowCount() > 0;
    // }

    // Đăng ký user
    public function register($data) {
        $this->db->query('INSERT INTO users (full_name, email, password) VALUES(:full_name, :email, :password)');
        // Bind values
        $this->db->bind(':full_name', $data['full_name']);
        $this->db->bind(':email', $data['email']);
        $this->db->bind(':password', $data['password']);

        // Execute
        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }

    // Đăng nhập user
    public function login($email, $password) {
        $this->db->query('SELECT * FROM users WHERE email = :email');
        $this->db->bind(':email', $email);
        $row = $this->db->single();

        if ($row) {
            $hashed_password = $row->password;
            if (password_verify($password, $hashed_password)) {
                return $row;
            }
        }
        return false;
    }

    public function findById($id) {
        $this->db->query('SELECT id, full_name, email, phone_number, role FROM users WHERE id = :id');
        $this->db->bind(':id', $id);
        return $this->db->single();
    }

    public function updateProfile($data) {
        $this->db->query('UPDATE users SET full_name = :full_name, phone_number = :phone_number WHERE id = :id');
        $this->db->bind(':id', $data['id']);
        $this->db->bind(':full_name', $data['full_name']);
        $this->db->bind(':phone_number', $data['phone_number']);
        return $this->db->execute();
    }

    /**
     * Lấy danh sách tất cả người dùng (khách hàng).
     * @return array Danh sách người dùng.
     */
    public function findAll() {
        $this->db->query("SELECT id, full_name, email, phone_number, created_at FROM users WHERE role = 'customer' ORDER BY created_at DESC");
        return $this->db->resultSet();
    }


    public function createPasswordResetToken($email) {
        // Tạo một token ngẫu nhiên, an toàn
        $token = bin2hex(random_bytes(32));
        // Token sẽ hết hạn sau 1 giờ
        $expires_at = date("Y-m-d H:i:s", time() + 3600);

        // Lưu token đã được hash vào DB để tăng bảo mật
        $hashed_token = hash('sha256', $token);

        // Xóa token cũ (nếu có) và chèn token mới
        $this->db->query("DELETE FROM password_resets WHERE email = :email");
        $this->db->bind(':email', $email);
        $this->db->execute();
        
        $this->db->query("INSERT INTO password_resets (email, token, expires_at) VALUES (:email, :token, :expires_at)");
        $this->db->bind(':email', $email);
        $this->db->bind(':token', $hashed_token);
        $this->db->bind(':expires_at', $expires_at);
        
        if ($this->db->execute()) {
            return $token; // Trả về token gốc để tạo link
        }
        return false;
    }

    public function getUserByResetToken($token) {
        $hashed_token = hash('sha256', $token);
        $this->db->query("SELECT * FROM password_resets WHERE token = :token AND expires_at > NOW()");
        $this->db->bind(':token', $hashed_token);
        $reset_request = $this->db->single();

        if ($reset_request) {
            // Dùng lại hàm findUserByEmail đã sửa để lấy thông tin user
            return $this->findUserByEmail($reset_request->email, true);
        }
        return false;
    }

    // Thêm một hàm để cập nhật mật khẩu
    public function updatePassword($userId, $newPassword) {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $this->db->query("UPDATE users SET password = :password WHERE id = :id");
        $this->db->bind(':password', $hashedPassword);
        $this->db->bind(':id', $userId);
        return $this->db->execute();
    }

    // Thêm hàm để xóa token sau khi đã dùng
    public function deletePasswordResetToken($email) {
        $this->db->query("DELETE FROM password_resets WHERE email = :email");
        $this->db->bind(':email', $email);
        return $this->db->execute();
    }
    
    // Sửa lại hàm findUserByEmail để có thể trả về object
    public function findUserByEmail($email, $returnObject = false) {
        $this->db->query('SELECT * FROM users WHERE email = :email');
        $this->db->bind(':email', $email);
        $row = $this->db->single();
        
        if ($returnObject) {
            return $row;
        }
        return $this->db->rowCount() > 0;
    }
}