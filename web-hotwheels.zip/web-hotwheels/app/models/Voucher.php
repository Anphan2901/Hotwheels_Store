<?php
class Voucher {
    private $db;
    public function __construct() { $this->db = new Database; }

    public function findAll() {
        $this->db->query("SELECT * FROM vouchers ORDER BY end_date DESC");
        return $this->db->resultSet();
    }

    public function create($data) {
        $this->db->query("INSERT INTO vouchers (code, discount_type, discount_value, max_usage, start_date, end_date) VALUES (:code, :discount_type, :discount_value, :max_usage, :start_date, :end_date)");
        $this->db->bind(':code', $data['code']);
        $this->db->bind(':discount_type', $data['discount_type']);
        $this->db->bind(':discount_value', $data['discount_value']);
        $this->db->bind(':max_usage', $data['max_usage']);
        $this->db->bind(':start_date', $data['start_date']);
        $this->db->bind(':end_date', $data['end_date']);
        return $this->db->execute();
    }

    public function findByCode($code) {
        $this->db->query("SELECT * FROM vouchers WHERE code = :code AND is_active = 1 AND start_date <= NOW() AND end_date >= NOW() AND current_usage < max_usage");
        $this->db->bind(':code', $code);
        return $this->db->single();
    }
}