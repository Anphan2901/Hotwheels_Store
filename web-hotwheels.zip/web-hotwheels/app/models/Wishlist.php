<?php
class Wishlist {
    private $db;
    public function __construct() { $this->db = new Database; }

    public function add($userId, $productId) {
        // Bước 1: Kiểm tra xem sản phẩm đã tồn tại trong wishlist của user này chưa.
        $this->db->query("SELECT id FROM wishlists WHERE user_id = :user_id AND product_id = :product_id");
        $this->db->bind(':user_id', $userId);
        $this->db->bind(':product_id', $productId);
        
        // Phải thực thi câu lệnh SELECT trước khi kiểm tra kết quả
        $this->db->execute();

        // Nếu rowCount > 0, nghĩa là sản phẩm đã có trong wishlist, không làm gì cả và trả về true.
        if ($this->db->rowCount() > 0) {
            return true;
        }

        // Bước 2: Nếu chưa có, mới tiến hành thêm vào database.
        $this->db->query("INSERT INTO wishlists (user_id, product_id) VALUES (:user_id, :product_id)");
        $this->db->bind(':user_id', $userId);
        $this->db->bind(':product_id', $productId);
        
        // Trả về kết quả của lệnh INSERT
        return $this->db->execute();
    }

    public function findByUserId($userId) {
    // Câu lệnh này JOIN bảng wishlists với bảng products để lấy đầy đủ thông tin sản phẩm
    $this->db->query("
        SELECT p.* FROM wishlists w
        JOIN products p ON w.product_id = p.id
        WHERE w.user_id = :user_id AND p.is_active = TRUE
    ");
    $this->db->bind(':user_id', $userId);
    return $this->db->resultSet();
    }

}