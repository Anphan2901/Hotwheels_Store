<?php require_once __DIR__ . '/../../layouts/admin_header.php'; ?>
<h1>Thêm Danh mục mới</h1>
<form action="/web-hotwheels/admin/createCategory" method="POST">
    <div class="mb-3">
        <label class="form-label">Tên Danh mục</label>
        <input type="text" class="form-control" name="name" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Mô tả</label>
        <textarea class="form-control" name="description" rows="3"></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Lưu Danh mục</button>
</form>
<?php require_once __DIR__ . '/../../layouts/admin_footer.php'; ?>