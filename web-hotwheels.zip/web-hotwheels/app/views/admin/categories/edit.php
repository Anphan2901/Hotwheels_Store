<?php require_once __DIR__ . '/../../layouts/admin_header.php'; ?>
<div class="container mt-4">
    <h1>Sửa Danh mục</h1>
    <form action="/web-hotwheels/admin/editCategory/<?php echo $category->id; ?>" method="POST">
        <div class="mb-3">
            <label for="name" class="form-label">Tên Danh mục</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($category->name); ?>" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Mô tả</label>
            <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($category->description); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Lưu Thay đổi</button>
        <a href="/web-hotwheels/admin/categories" class="btn btn-secondary">Hủy</a>
    </form>
</div>
<?php require_once __DIR__ . '/../../layouts/admin_footer.php'; ?>