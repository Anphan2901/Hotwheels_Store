<?php require_once __DIR__ . '/../../layouts/admin_header.php'; ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h1>Quản lý Danh mục</h1>
    <a href="/web-hotwheels/admin/createCategory" class="btn btn-primary">Thêm Danh mục mới</a>
</div>
<table class="table table-dark table-striped">
    <thead><tr><th>ID</th><th>Tên Danh mục</th><th>Mô tả</th><th>Hành động</th></tr></thead>
    <tbody>
    <?php foreach ($categories as $category): ?>
        <tr>
            <td><?php echo $category->id; ?></td>
            <td><?php echo $category->name; ?></td>
            <td><?php echo $category->description; ?></td>
            <td><a href="/web-hotwheels/admin/editCategory/<?php echo $category->id; ?>" class="btn btn-warning btn-sm">Sửa</a></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php require_once __DIR__ . '/../../layouts/admin_footer.php'; ?>