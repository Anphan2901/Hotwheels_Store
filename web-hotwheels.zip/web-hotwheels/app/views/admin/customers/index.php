<?php require_once __DIR__ . '/../../layouts/admin_header.php'; ?>

<h1>Quản lý Khách hàng</h1>

<table class="table table-dark table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tên Khách hàng</th>
            <th>Email</th>
            <th>Số điện thoại</th>
            <th>Ngày đăng ký</th>
        </tr>
    </thead>
    <tbody>
    <?php if (!empty($customers)): ?>
        <?php foreach ($customers as $customer): ?>
        <tr>
            <td><?php echo $customer->id; ?></td>
            <td><?php echo htmlspecialchars($customer->full_name ?? ''); ?></td>
            <td><?php echo htmlspecialchars($customer->email ?? ''); ?></td>
            <td><?php echo htmlspecialchars($customer->phone_number ?? ''); ?></td>
            <td><?php echo date('d/m/Y', strtotime($customer->created_at)); ?></td>
        </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr>
            <td colspan="5" class="text-center">Chưa có khách hàng nào.</td>
        </tr>
    <?php endif; ?>
</tbody>
</table>

<?php require_once __DIR__ . '/../../layouts/admin_footer.php'; ?>