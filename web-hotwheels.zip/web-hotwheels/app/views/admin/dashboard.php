<?php require_once __DIR__ . '/../layouts/admin_header.php'; ?>

<h1>Chào mừng đến với trang quản trị</h1>
<p>Đây là khu vực tổng quan, nơi bạn có thể xem các báo cáo và thống kê nhanh.</p>
<?php require_once __DIR__ . '/../layouts/admin_footer.php'; ?>