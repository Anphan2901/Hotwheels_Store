<?php require_once __DIR__ . '/../../layouts/admin_header.php'; ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1>Quản lý Đơn hàng</h1>
    </div>

    <table class="table table-dark table-striped">
        <thead>
            <tr>
                <th>Mã Đơn</th>
                <th>Khách hàng</th>
                <th>Ngày Đặt</th>
                <th>Tổng Tiền</th>
                <th>Trạng Thái</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($orders)): ?>
                <?php foreach ($orders as $order): ?>
                <tr>
                    <td><?php echo htmlspecialchars($order->order_code); ?></td>
                    <td><?php echo htmlspecialchars($order->customer_name); ?></td>
                    <td><?php echo date('d/m/Y H:i', strtotime($order->created_at)); ?></td>
                    <td><?php echo number_format($order->total_amount, 0, ',', '.'); ?> VNĐ</td>
                    <td><span class="badge bg-info text-dark"><?php echo ucfirst($order->status); ?></span></td>
                    <td>
                        <a href="/web-hotwheels/admin/viewOrder/<?php echo $order->id; ?>" class="btn btn-primary btn-sm">Xem Chi tiết</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="text-center">Chưa có đơn hàng nào.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php require_once __DIR__ . '/../../layouts/admin_footer.php'; ?>