<?php require_once __DIR__ . '/../../layouts/admin_header.php'; ?>

<?php
// Tính toán tổng tiền tạm tính và giảm giá
$subtotal = 0;
foreach($order->items as $item) {
    $subtotal += $item->price * $item->quantity;
}
$discount = $subtotal - $order->total_amount;
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1>Chi tiết Đơn hàng #<?php echo htmlspecialchars($order-> order_code); ?></h1>
        <a href="/web-hotwheels/admin/orders" class="btn btn-secondary">Quay lại Danh sách</a>
    </div>

    <div class="row">
        <div class="col-md-8">
            <h5>Các sản phẩm trong đơn</h5>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Sản phẩm</th>
                        <th class="text-center">Số lượng</th>
                        <th class="text-end">Đơn giá (giá gốc)</th>
                        <th class="text-end">Thành tiền</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($order->items as $item): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item->product_name); ?></td>
                        <td class="text-center"><?php echo $item->quantity; ?></td>
                        <td class="text-end"><?php echo number_format($item->price, 0, ',', '.'); ?> VNĐ</td>
                        <td class="text-end"><?php echo number_format($item->price * $item->quantity, 0, ',', '.'); ?> VNĐ</td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="col-md-4">
            <div class="card p-3 text-white" style="background-color: #212529;">
                <h5 class="card-title">Thông tin đơn hàng</h5>
                <hr>
                <p><strong>Khách hàng:</strong><br><?php echo htmlspecialchars($order->full_name); ?> (<?php echo htmlspecialchars($order->email); ?>)</p>
                <p><strong>Địa chỉ giao hàng:</strong><br><?php echo htmlspecialchars($order->shipping_address); ?></p>
                <p><strong>Ghi chú:</strong><br><?php echo htmlspecialchars($order->notes ?? 'Không có'); ?></p>
                <hr>

                <div class="d-flex justify-content-between">
                    <span>Tạm tính:</span>
                    <span><?php echo number_format($subtotal, 0, ',', '.'); ?> VNĐ</span>
                </div>

                <?php if ($discount > 0): ?>
                <div class="d-flex justify-content-between text-success">
                    <span>Giảm giá:</span>
                    <span>-<?php echo number_format($discount, 0, ',', '.'); ?> VNĐ</span>
                </div>
                <?php endif; ?>

                <hr>
                <p class="d-flex justify-content-between fw-bold fs-5">
                    <span>Tổng tiền cuối cùng:</span>
                    <span><?php echo number_format($order->total_amount, 0, ',', '.'); ?> VNĐ</span>
                </p>

                <hr>

                <p class="mb-1"><strong>Trạng thái hiện tại:</strong> <span class="badge bg-primary"><?php echo ucfirst($order->status); ?></span></p>
                <form action="/web-hotwheels/admin/updateOrderStatus/<?php echo $order->id; ?>" method="POST">
                    <label class="form-label">Cập nhật trạng thái</label>
                    <select name="status" class="form-select">
                        <option value="pending" <?php if($order->status == 'pending') echo 'selected'; ?>>Chờ xử lý</option>
                        <option value="confirmed" <?php if($order->status == 'confirmed') echo 'selected'; ?>>Đã xác nhận</option>
                        <option value="shipping" <?php if($order->status == 'shipping') echo 'selected'; ?>>Đang giao hàng</option>
                        <option value="completed" <?php if($order->status == 'completed') echo 'selected'; ?>>Đã hoàn thành</option>
                        <option value="cancelled" <?php if($order->status == 'cancelled') echo 'selected'; ?>>Đã hủy</option>
                    </select>
                    <button type="submit" class="btn btn-primary w-100 mt-2">Cập nhật</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../layouts/admin_footer.php'; ?>