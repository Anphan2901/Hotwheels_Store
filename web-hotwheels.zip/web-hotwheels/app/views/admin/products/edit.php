<?php require_once __DIR__ . '/../../layouts/admin_header.php'; ?>

<div class="container mt-4">
    <h1>Sửa Sản phẩm</h1>

    <form action="/web-hotwheels/admin/editProduct/<?php echo $product->id; ?>" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="name" class="form-label">Tên sản phẩm</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($product->name); ?>" required>
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Mô tả</label>
            <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($product->description); ?></textarea>
        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="price" class="form-label">Giá (VNĐ)</label>
                <input type="number" class="form-control" id="price" name="price" value="<?php echo $product->price; ?>" required>
            </div>
            <div class="col-md-6 mb-3">
                <label for="stock_quantity" class="form-label">Số lượng tồn kho</label>
                <input type="number" class="form-control" id="stock_quantity" name="stock_quantity" value="<?php echo $product->stock_quantity; ?>" required>
            </div>
        </div>

        <div class="mb-3">
            <label for="category_id" class="form-label">Danh mục</label>
            <select class="form-select" id="category_id" name="category_id" required>
                <option value="" disabled>-- Chọn danh mục --</option>
                
                <?php foreach ($categories as $category): ?>
                    <option value="<?php echo $category->id; ?>" <?php if ($product->category_id == $category->id) echo 'selected'; ?>>
                        <?php echo htmlspecialchars($category->name); ?>
                    </option>
                <?php endforeach; ?>

            </select>
        </div>
        
        <div class="mb-3">
            <label for="thumbnail" class="form-label">Thay đổi Ảnh đại diện (để trống nếu không muốn đổi)</label>
            <input type="file" class="form-control" id="thumbnail" name="thumbnail" accept="image/*">
        </div>

        <button type="submit" class="btn btn-primary">Lưu Thay đổi</button>
        <a href="/web-hotwheels/admin/products" class="btn btn-secondary">Hủy</a>
    </form>
</div>

<?php require_once __DIR__ . '/../../layouts/admin_footer.php'; ?>