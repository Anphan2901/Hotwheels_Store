<?php require_once __DIR__ . '/../../layouts/admin_header.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1>Quản lý Sản phẩm</h1>
    <a href="/web-hotwheels/admin/createProduct" class="btn btn-primary">Thêm Sản phẩm mới</a>
</div>

<table class="table table-striped table-hover">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tên sản phẩm</th>
            <th>Danh mục</th>
            <th>Giá</th>
            <th>Tồn kho</th>
            <th>Trạng thái</th> <th>Hành động</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($products)): ?>
            <?php foreach ($products as $product): ?>
            <tr>
                <td><?php echo $product->id; ?></td>
                <td><?php echo htmlspecialchars($product->name); ?></td>
                <td><?php echo htmlspecialchars($product->category_name ?? 'N/A'); ?></td>
                <td><?php echo number_format($product->price, 0, ',', '.'); ?> VNĐ</td>
                <td><?php echo $product->stock_quantity; ?></td>
                
                <td>
                    <?php if ($product->is_active): ?>
                        <span class="badge bg-success">Đang hoạt động</span>
                    <?php else: ?>
                        <span class="badge bg-danger">Đã ẩn</span>
                    <?php endif; ?>
                </td>

                <td>
                    <a href="/web-hotwheels/admin/editProduct/<?php echo $product->id; ?>" class="btn btn-warning btn-sm">Sửa</a>
                    <a href="/web-hotwheels/admin/deleteProduct/<?php echo $product->id; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hành động này sẽ ẩn sản phẩm khỏi trang bán hàng. Bạn chắc chứ?')">Xóa</a>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="7" class="text-center">Chưa có sản phẩm nào. Hãy thêm sản phẩm mới.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require_once __DIR__ . '/../../layouts/admin_footer.php'; ?>