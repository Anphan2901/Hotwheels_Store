<?php require_once __DIR__ . '/../../layouts/admin_header.php'; ?>
<div class="container mt-4">
    <h1>Tạo Mã giảm giá mới</h1>
    <form action="/web-hotwheels/admin/createVoucher" method="POST">
        <div class="mb-3">
            <label class="form-label">Mã Code (ví dụ: SALE50K, FREESHIP)</label>
            <input type="text" class="form-control" name="code" required>
        </div>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">Loại giảm giá</label>
                <select name="discount_type" class="form-select">
                    <option value="fixed">Giảm số tiền cố định (VNĐ)</option>
                    <option value="percent">Giảm theo phần trăm (%)</option>
                </select>
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Giá trị (ví dụ: 50000 hoặc 10)</label>
                <input type="number" class="form-control" name="discount_value" required>
            </div>
        </div>
        <div class="mb-3">
            <label class="form-label">Tổng số lượt sử dụng</label>
            <input type="number" class="form-control" name="max_usage" value="100" required>
        </div>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">Ngày bắt đầu</label>
                <input type="datetime-local" class="form-control" name="start_date" required>
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Ngày kết thúc</label>
                <input type="datetime-local" class="form-control" name="end_date" required>
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Lưu Mã giảm giá</button>
    </form>
</div>
<?php require_once __DIR__ . '/../../layouts/admin_footer.php'; ?>