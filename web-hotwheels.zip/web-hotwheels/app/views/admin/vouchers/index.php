<?php require_once __DIR__ . '/../../layouts/admin_header.php'; ?>
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1>Quản lý Mã giảm giá</h1>
        <a href="/web-hotwheels/admin/createVoucher" class="btn btn-primary">Tạo Mã mới</a>
    </div>
    <table class="table table-dark table-striped">
        <thead>
            <tr>
                <th>Mã Code</th><th>Loại</th><th>Giá trị</th><th>Lượt sử dụng</th><th>Ngày hết hạn</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($vouchers as $voucher): ?>
            <tr>
                <td><?php echo htmlspecialchars($voucher->code); ?></td>
                <td><?php echo $voucher->discount_type; ?></td>
                <td><?php echo $voucher->discount_value; ?></td>
                <td><?php echo $voucher->current_usage . ' / ' . $voucher->max_usage; ?></td>
                <td><?php echo date('d/m/Y', strtotime($voucher->end_date)); ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php require_once __DIR__ . '/../../layouts/admin_footer.php'; ?>