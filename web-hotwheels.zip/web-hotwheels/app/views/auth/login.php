<?php require_once __DIR__ . '/../layouts/main_header.php'; ?>

<div class="d-flex justify-content-center align-items-center" style="min-height: 80vh;">
    <div class="card p-4 shadow-sm" style="width: 100%; max-width: 450px;">
        <h2 class="text-center mb-3 text-uppercase fw-bold">Đăng nhập</h2>
        <p class="text-center text-body-secondary mb-4">Vui lòng nhập email và mật khẩu!</p>
        
        <?php if(isset($_GET['status']) && $_GET['status'] == 'reset_success'): ?>
            <div class="alert alert-success">Mật khẩu đã được tạo lại thành công. Bạn có thể đăng nhập ngay bây giờ.</div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <form action="/web-hotwheels/auth/handleLogin" method="POST">
            <div class="mb-3">
                <label for="email" class="form-label">Email*</label>
                <input type="email" name="email" id="email" class="form-control" required>
            </div>
            <div class="mb-4">
                <label for="password" class="form-label">Mật khẩu*</label>
                <input type="password" name="password" id="password" class="form-control" required>
            </div>
            <div class="d-grid">
                <button type="submit" class="btn btn-primary btn-lg">Đăng nhập</button>
            </div>
            <div class="text-center mt-3">
                <a href="/web-hotwheels/auth/forgotPassword" class="text-body-secondary text-decoration-none">Quên mật khẩu?</a>
            </div>
        </form>
        <hr>
        <div class="text-center">
             <p class="mb-0">Chưa có tài khoản? <a href="/web-hotwheels/auth/register" class="fw-bold text-decoration-none">Đăng ký</a></p>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/main_footer.php'; ?>