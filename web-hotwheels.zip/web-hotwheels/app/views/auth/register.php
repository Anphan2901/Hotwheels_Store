<?php require_once __DIR__ . '/../layouts/main_header.php'; ?>

<div class="d-flex justify-content-center align-items-center" style="min-height: 80vh;">
    <div class="card p-4 shadow-sm" style="width: 100%; max-width: 500px;">
        <h2 class="text-center mb-4 text-uppercase fw-bold">Đăng ký</h2>

        <?php if (isset($data['errors']) && !empty($data['errors'])): ?>
            <div class="alert alert-danger">
                <?php foreach ($data['errors'] as $err): ?>
                    <p class="mb-0"><?php echo $err; ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form action="/web-hotwheels/auth/handleRegister" method="POST">
            <div class="mb-3">
                <label class="form-label">Họ và Tên*</label>
                <input type="text" name="full_name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Email*</label>
                <input type="email" name="email" class="form-control" required>
            </div>
             <div class="mb-3">
                <label class="form-label">Mật khẩu*</label>
                <input type="password" name="password" class="form-control" required>
            </div>
             <div class="mb-3">
                <label class="form-label">Xác nhận Mật khẩu*</label>
                <input type="password" name="confirm_password" class="form-control" required>
            </div>
            <div class="d-grid">
                <button type="submit" class="btn btn-primary btn-lg">Đăng ký</button>
            </div>
        </form>
        <hr>
        <div class="text-center">
            <p class="mb-0">Đã có tài khoản? <a href="/web-hotwheels/auth/login" class="fw-bold text-decoration-none">Quay lại trang đăng nhập</a></p>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/main_footer.php'; ?>