<?php require_once __DIR__ . '/../layouts/main_header.php'; ?>
<div class="d-flex justify-content-center align-items-center" style="min-height: 70vh;">
    <div class="card p-4 text-center">
        <h2>Kiểm tra "Hộp thư" của bạn</h2>
        <p>Một link để tạo lại mật khẩu đã được tạo. Trong thực tế, link này sẽ được gửi đến email của bạn.</p>
        <p>Vui lòng sao chép và dán link dưới đây vào thanh địa chỉ của trình duyệt:</p>
        <textarea readonly class="form-control" rows="3"><?php echo $reset_link; ?></textarea>
        <a href="/web-hotwheels/home" class="btn btn-secondary mt-3">Quay về trang chủ</a>
    </div>
</div>
<?php require_once __DIR__ . '/../layouts/main_footer.php'; ?>