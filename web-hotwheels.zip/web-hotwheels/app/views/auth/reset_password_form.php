<?php require_once __DIR__ . '/../layouts/main_header.php'; ?>
<div class="d-flex justify-content-center align-items-center" style="min-height: 70vh;">
    <div class="card p-4" style="width: 100%; max-width: 450px;">
        <h2 class="text-center mb-4">Tạo Mật khẩu mới</h2>
        <?php if (isset($error)): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>
        <form action="/web-hotwheels/auth/handleResetPassword" method="POST">
            <input type="hidden" name="token" value="<?php echo htmlspecialchars($_GET['token']); ?>">
            <div class="mb-3">
                <label class="form-label">Mật khẩu mới*</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Xác nhận mật khẩu mới*</label>
                <input type="password" name="confirm_password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Lưu Mật khẩu</button>
        </form>
    </div>
</div>
<?php require_once __DIR__ . '/../layouts/main_footer.php'; ?>