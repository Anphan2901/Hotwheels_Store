<?php require_once __DIR__ . '/../layouts/main_header.php'; ?>

<h1>Giỏ Hàng Của Bạn</h1>

<?php
// --- KHỐI TÍNH TOÁN (giữ nguyên) ---
$subtotal = 0;
if (!empty($cart)) {
    foreach($cart as $item) {
        $subtotal += $item['price'] * $item['quantity'];
    }
}

$discount = 0;
if (isset($_SESSION['voucher'])) {
    $voucher = $_SESSION['voucher'];
    if ($voucher['discount_type'] == 'fixed') {
        $discount = $voucher['discount_value'];
    } else { // percent
        $discount = ($subtotal * $voucher['discount_value']) / 100;
    }
}
$total = $subtotal - $discount;
?>

<div class="row">

    <div class="col-md-8">
        <?php if (!empty($cart)): ?>
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th style="width: 50%;">Sản phẩm</th>
                        <th class="text-center">Giá</th>
                        <th class="text-center">Số lượng</th>
                        <th class="text-end">Tổng cộng</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($cart as $id => $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['name']); ?></td>
                            <td class="text-center"><?php echo number_format($item['price'], 0, ',', '.'); ?> VNĐ</td>
                            <td class="text-center"><?php echo $item['quantity']; ?></td>
                            <td class="text-end"><?php echo number_format($item['price'] * $item['quantity'], 0, ',', '.'); ?> VNĐ</td>
                            <td class="text-center">
                                <a href="/web-hotwheels/cart/remove/<?php echo $id; ?>" class="btn btn-danger btn-sm">Xóa</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="alert alert-secondary">Giỏ hàng của bạn đang trống. Hãy <a href="/web-hotwheels/home" class="alert-link">quay lại cửa hàng</a> để mua sắm.</div>
        <?php endif; ?>
    </div>

    <div class="col-md-4">
        <div class="card p-3">
            <h4 class="mb-3">Tóm tắt</h4>
            <hr>
            
            <div class="d-flex justify-content-between">
                <span>Tạm tính:</span>
                <span><?php echo number_format($subtotal, 0, ',', '.'); ?> VNĐ</span>
            </div>

            <?php if (isset($voucher)): ?>
                <div class="d-flex justify-content-between text-success mt-2">
                    <span>Giảm giá (<?php echo htmlspecialchars($voucher['code']); ?>):</span>
                    <span>-<?php echo number_format($discount, 0, ',', '.'); ?> VNĐ</span>
                </div>
            <?php else: ?>
                 <div class="d-flex justify-content-between text-success mt-2" style="height: 24px;"></div>
            <?php endif; ?>

            <hr>
            <div class="d-flex justify-content-between fw-bold fs-5">
                <span>Tổng cộng:</span>
                <span><?php echo number_format($total, 0, ',', '.'); ?> VNĐ</span>
            </div>
            <hr>

            <?php if (!isset($voucher)): ?>
                <form action="/web-hotwheels/cart/applyVoucher" method="POST" class="mt-2">
                    <label class="form-label">Mã giảm giá</label>
                    <div class="input-group">
                        <input type="text" name="code" class="form-control" placeholder="Nhập mã...">
                        <button type="submit" class="btn btn-secondary">Áp dụng</button>
                    </div>
                </form>
                <?php if(isset($_SESSION['voucher_error'])): ?>
                    <div class="text-danger mt-2"><?php echo $_SESSION['voucher_error']; unset($_SESSION['voucher_error']); ?></div>
                <?php endif; ?>
            <?php else: ?>
                <a href="/web-hotwheels/cart/removeVoucher" class="btn btn-sm btn-outline-danger mt-2">Hủy mã giảm giá</a>
            <?php endif; ?>
            
            <?php if (!empty($cart)): ?>
                <a href="/web-hotwheels/order" class="btn btn-primary w-100 mt-4">Tiến hành Thanh toán</a>
            <?php endif; ?>
        </div>
    </div>

</div> <?php require_once __DIR__ . '/../layouts/main_footer.php'; ?>