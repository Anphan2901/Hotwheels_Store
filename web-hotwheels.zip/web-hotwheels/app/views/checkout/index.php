<?php require_once __DIR__ . '/../layouts/main_header.php'; ?>

<?php
// --- KHỐI TÍNH TOÁN - ĐƯỢC ĐẶT LÊN ĐẦU ---
// Khối code này giống hệt trên trang giỏ hàng để đảm bảo logic nhất quán
$subtotal = 0;
if (!empty($cart)) {
    foreach($cart as $item) {
        $subtotal += $item['price'] * $item['quantity'];
    }
}

$discount = 0;
if (isset($voucher)) {
    if ($voucher['discount_type'] == 'fixed') {
        $discount = $voucher['discount_value'];
    } else { // percent
        $discount = ($subtotal * $voucher['discount_value']) / 100;
    }
}

$total = $subtotal - $discount;
?>

<div class="row">
    <div class="col-md-7">
        <h2>Thông tin giao hàng</h2>
        <form action="/web-hotwheels/order/placeOrder" method="POST">
            <div class="mb-3">
                <label for="address" class="form-label">Địa chỉ nhận hàng đầy đủ</label>
                <textarea name="address" id="address" class="form-control" rows="4" placeholder="Vui lòng nhập số nhà, tên đường, phường/xã, quận/huyện, tỉnh/thành phố..." required></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Ghi chú (tùy chọn)</label>
                <textarea name="notes" class="form-control" rows="3"></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Phương thức thanh toán</label>
                <div class="form-check p-3 border rounded" style="background-color: #212529;">
                    <input class="form-check-input" type="radio" checked>
                    <label class="form-check-label">
                        Thanh toán khi nhận hàng (COD)
                    </label>
                </div>
            </div>
            <button type="submit" class="btn btn-primary w-100 btn-lg">HOÀN TẤT ĐƠN HÀNG</button>
        </form>
    </div>

    <div class="col-md-5">
        <h2>Tóm tắt đơn hàng</h2>
        <div class="card p-3" style="background-color: #212529;">
            
            <?php foreach($cart as $item): ?>
                <div class="d-flex justify-content-between mb-2">
                    <span><?php echo htmlspecialchars($item['name']); ?> x <?php echo $item['quantity']; ?></span>
                    <span><?php echo number_format($item['price'] * $item['quantity'], 0, ',', '.'); ?> VNĐ</span>
                </div>
            <?php endforeach; ?>
            <hr>

            <div class="d-flex justify-content-between">
                <span>Tạm tính:</span>
                <span><?php echo number_format($subtotal, 0, ',', '.'); ?> VNĐ</span>
            </div>

            <?php if ($discount > 0): ?>
                <div class="d-flex justify-content-between text-success mt-2">
                    <span>Giảm giá:</span>
                    <span>-<?php echo number_format($discount, 0, ',', '.'); ?> VNĐ</span>
                </div>
            <?php endif; ?>
            <hr>

            <div class="d-flex justify-content-between fw-bold fs-5">
                <span>Tổng cộng:</span>
                <span><?php echo number_format($total, 0, ',', '.'); ?> VNĐ</span>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/main_footer.php'; ?>