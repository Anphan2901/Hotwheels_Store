<?php require_once __DIR__ . '/../layouts/main_header.php'; ?>

<div class="text-center py-5">
    <h1 class="display-4">Đặt hàng thành công!</h1>
    <p class="lead">Cảm ơn bạn đã mua hàng. Chúng tôi sẽ xử lý đơn hàng của bạn trong thời gian sớm nhất.</p>
    <hr>
    <p>Bạn có muốn tiếp tục mua sắm không?</p>
    <a class="btn btn-primary" href="/web-hotwheels/home" role="button">Quay về trang chủ</a>
</div>

<?php require_once __DIR__ . '/../layouts/main_footer.php'; ?>