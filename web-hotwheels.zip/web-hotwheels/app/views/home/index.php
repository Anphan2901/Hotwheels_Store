<?php require_once __DIR__ . '/../layouts/main_header.php'; ?>

<div class="text-center mb-5">
    <img src="/web-hotwheels/public/uploads/banner-moi.jpg" class="img-fluid" alt="RLC Exclusive Banner">
</div>

<div class="mb-4">
    <form action="/web-hotwheels/home" method="GET" class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Tìm kiếm sản phẩm..." name="search" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
        <button class="btn btn-primary" type="submit">Tìm</button>
    </form>
</div>

<div class="row">
    <div class="col-md-3">
        <h4>Danh mục</h4>
        <div class="list-group">
            <a href="/web-hotwheels/home" class="list-group-item list-group-item-action <?php if(empty($_GET['category'])) echo 'active'; ?>">Tất cả sản phẩm</a>
            <?php if (!empty($categories)): ?>
                <?php foreach($categories as $category): ?>
                    <a href="/web-hotwheels/home?category=<?php echo $category->id; ?>" class="list-group-item list-group-item-action <?php if(isset($_GET['category']) && $_GET['category'] == $category->id) echo 'active'; ?>">
                        <?php echo htmlspecialchars($category->name); ?>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="col-md-9">

        <div class="d-flex justify-content-end mb-3">
            <div style="width: 250px;">
                <form id="sort-form" action="" method="GET">
                    <input type="hidden" name="search" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                    <input type="hidden" name="category" value="<?php echo isset($_GET['category']) ? htmlspecialchars($_GET['category']) : ''; ?>">
                    
                    <select class="form-select" name="sort" onchange="this.form.submit()">
                        <option value="default" <?php if (empty($_GET['sort'])) echo 'selected'; ?>>Sắp xếp theo: Mặc định</option>
                        <option value="price_asc" <?php if (isset($_GET['sort']) && $_GET['sort'] == 'price_asc') echo 'selected'; ?>>Giá: Thấp đến Cao</option>
                        <option value="price_desc" <?php if (isset($_GET['sort']) && $_GET['sort'] == 'price_desc') echo 'selected'; ?>>Giá: Cao đến Thấp</option>
                        <option value="name_asc" <?php if (isset($_GET['sort']) && $_GET['sort'] == 'name_asc') echo 'selected'; ?>>Tên: A đến Z</option>
                        <option value="name_desc" <?php if (isset($_GET['sort']) && $_GET['sort'] == 'name_desc') echo 'selected'; ?>>Tên: Z đến A</option>
                    </select>
                </form>
            </div>
        </div>

        <div class="row">
            <?php if (!empty($products)): ?>
                <?php foreach ($products as $product): ?>
                <div class="col-md-4 mb-4">
                    <div class="card product-card h-100">
    <a href="/web-hotwheels/product/show/<?php echo $product->id; ?>" class="text-decoration-none">
        <img src="/web-hotwheels/<?php echo $product->thumbnail ?? 'public/uploads/placeholder.jpg'; ?>" class="card-img-top" alt="<?php echo htmlspecialchars($product->name); ?>">

        <div class="card-body d-flex flex-column">
            <h5 class="card-title text-white"><?php echo htmlspecialchars($product->name); ?></h5>
        </div>
    </a>
    <div class="card-footer bg-transparent border-0 d-flex flex-column">
         <p class="card-text fw-bold"><?php echo number_format((float)$product->price, 0, ',', '.'); ?> VNĐ</p>

        <div class="mt-auto">
             <a href="/web-hotwheels/cart/add/<?php echo $product->id; ?>" class="btn btn-sm btn-primary">Thêm vào giỏ</a>
             <a href="/web-hotwheels/user/addToWishlist/<?php echo $product->id; ?>" class="btn btn-sm btn-outline-danger" title="Thêm vào danh sách yêu thích">♥</a>
        </div>
    </div>
</div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12">
                    <p>Không tìm thấy sản phẩm nào.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/main_footer.php'; ?>