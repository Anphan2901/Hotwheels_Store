</main> <footer class="pt-5 pb-4 bg-body-tertiary text-body-secondary mt-5 border-top">
        <div class="container">
            <div class="row">

                <div class="col-lg-3 col-md-6 mb-4">
                    <h5 class="text-uppercase fw-bold mb-4">HADES STORE SYSTEM</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2">HADES STUDIO Store 1: 26 LY TU TRONG STREET, DISTRICT 1, HOCHIMINH.</li>
                        <li class="mb-2">Store 2: 140 NGUYEN HY QUANG, DONG DA DISTRICT, HANOI.</li>
                        <li class="mb-2">Store 3: Floor B1 VINCOM LY TU TRONG, DISTRICT 1, HOCHIMINH.</li>
                        <li class="mb-2">Store 4: Tầng 4, GIGA MALL, HCM</li>
                        <li class="mb-2">Store 5: 152 TRAN QUANG DIEU, WARD 14, DISTRICT 3, HCM</li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4">
                    <h5 class="text-uppercase fw-bold mb-4">POLICY</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="#" class="text-reset text-decoration-none">Website usage policy</a></li>
                        <li class="mb-2"><a href="#" class="text-reset text-decoration-none">Payment Options</a></li>
                        <li class="mb-2"><a href="#" class="text-reset text-decoration-none">Returns & Exchanges</a></li>
                        <li class="mb-2"><a href="#" class="text-reset text-decoration-none">Shipping Services</a></li>
                        <li class="mb-2"><a href="#" class="text-reset text-decoration-none">Terms of Service</a></li>
                        <li class="mb-2"><a href="#" class="text-reset text-decoration-none">Shopping Guide</a></li>
                        <li class="mb-2"><a href="#" class="text-reset text-decoration-none">Privacy Policy</a></li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4">
                    <h5 class="text-uppercase fw-bold mb-4">CONTACT INFO</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2">CÔNG TY TNHH HADES</li>
                        <li class="mb-2">Hotline: 000000000 (10h - 18h)</li>
                        <li class="mb-2">Date granted: 20/07/2025</li>
                        <li class="mb-2">Recruitment: hr@hades.vn</li>
                        <li class="mb-2">Website: hades_store.vn</li>
                        <li class="mb-2">For business: contact@hades_store.vn</li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6 mb-4">
                    <h5 class="text-uppercase fw-bold mb-4">FOLLOW US ON SOCIAL MEDIA</h5>
                    <div>
                        <a href="#" class="text-reset me-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16">
                                <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0 0 3.603 0 8.049c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z"/>
                            </svg>
                        </a>
                        <a href="#" class="text-reset">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-instagram" viewBox="0 0 16 16">
                                <path d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.703.01 5.556 0 5.829 0 8s.01 2.444.048 3.297c.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.556 15.99 5.829 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.444 16 10.171 16 8s-.01-2.444-.048-3.298c-.04-.851-.175-1.433-.372-1.942a3.916 3.916 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.444.01 10.171 0 8 0zm0 1.442c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.282.24.705.275 1.486.039.843.047 1.096.047 3.232s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.486a2.47 2.47 0 0 1-.599.92c-.28.28-.546.453-.92.598-.282.11-.705.24-1.486.275-.843.038-1.096.047-3.232.047s-2.389-.009-3.232-.047c-.78-.036-1.203-.166-1.486-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.283-.24-.705-.275-1.486-.038-.843-.046-1.096-.046-3.232s.008-2.389.046-3.232c.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.283-.11.705-.24 1.486-.276.843-.038 1.096-.047 3.232-.047z"/>
                                <path d="M8 4.405a3.595 3.595 0 1 0 0 7.19 3.595 3.595 0 0 0 0-7.19zm0 6.195a2.6 2.6 0 1 1 0-5.2 2.6 2.6 0 0 1 0 5.2zM12.636 3.785a.96.96 0 1 1-1.92 0 .96.96 0 0 1 1.92 0z"/>
                            </svg>
                        </a>
                    </div>
                </div>

            </div>
            <hr class="my-4">
            <div class="text-center">
                <p>&copy; <?php echo date('Y'); ?> HADES. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        (function() {
            const sunIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-sun-fill" viewBox="0 0 16 16"><path d="M8 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 .5 0zM12.293 2.293a.5.5 0 0 1 .707.707L12 4.007a.5.5 0 0 1-.707-.707l1.007-1.007zM15 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM12 12a.5.5 0 0 1-.707.707l-1.007-1.007a.5.5 0 0 1 .707.707l1.007 1.007zM8 16a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 1 1 0v2a.5.5 0 0 1-.5.5zM3.707 12.293a.5.5 0 0 1-.707-.707L4 10.586a.5.5 0 0 1 .707.707l-1.007 1.007zM0 8a.5.5 0 0 1 .5-.5h2a.5.5 0 0 1 0 1H.5A.5.5 0 0 1 0 8zm4-5.707a.5.5 0 0 1 .707 0l1.007 1.007a.5.5 0 0 1-.707.707L4.007 3.707a.5.5 0 0 1 0-.707z"/></svg>`;
            const moonIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-moon-stars-fill" viewBox="0 0 16 16"><path d="M6 .278a.768.768 0 0 1 .08.858 7.208 7.208 0 0 0-.878 3.46c0 4.021 3.278 7.277 7.318 7.277.527 0 1.04-.055 1.533-.16a.787.787 0 0 1 .81.316.733.733 0 0 1-.031.893A8.349 8.349 0 0 1 8.344 16C3.734 16 0 12.286 0 7.71 0 4.266 2.114 1.312 5.124.06A.752.752 0 0 1 6 .278z"/><path d="M10.794 3.148a.217.217 0 0 1 .412 0l.387 1.162h1.224a.217.217 0 0 1 .153.372l-.986.993.39 1.162a.217.217 0 0 1-.316.242l-1.042-.515-1.042.515a.217.217 0 0 1-.316-.242l.39-1.162-.986-.993a.217.217 0 0 1 .153-.372h1.224l.387-1.162zM13.863.099a.145.145 0 0 1 .274 0l.258.774c.115.346.386.617.732.732l.774.258a.145.145 0 0 1 0 .274l-.774.258a1.156 1.156 0 0 0-.732.732l-.258.774a.145.145 0 0 1-.274 0l-.258-.774a1.156 1.156 0 0 0-.732-.732l-.774-.258a.145.145 0 0 1 0-.274l.774.258c.346-.115.617-.386.732-.732L13.863.1z"/></svg>`;
            
            const htmlElement = document.documentElement;
            const themeToggleBtn = document.getElementById('theme-toggle-btn');
    
            const setTheme = (theme) => {
                htmlElement.setAttribute('data-bs-theme', theme);
                localStorage.setItem('theme', theme);
                if (themeToggleBtn) {
                    themeToggleBtn.innerHTML = theme === 'dark' ? sunIcon : moonIcon;
                }
            };
    
            const getPreferredTheme = () => {
                const storedTheme = localStorage.getItem('theme');
                if (storedTheme) { return storedTheme; }
                return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
            };
    
            setTheme(getPreferredTheme());
    
            if (themeToggleBtn) {
                themeToggleBtn.addEventListener('click', () => {
                    const newTheme = htmlElement.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark';
                    setTheme(newTheme);
                });
            }
        })();
    </script>
    </body>
</html>