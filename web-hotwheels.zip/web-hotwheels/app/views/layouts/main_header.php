<!DOCTYPE html>
<html lang="vi" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hades Hotwheels Store</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/web-hotwheels/public/css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary sticky-top">
    <div class="container">
        <a class="navbar-brand fw-bold" href="/web-hotwheels/home">HADES™</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link" href="/web-hotwheels/home">SHOP ALL</a></li>
                <li class="nav-item"><a class="nav-link" href="/web-hotwheels/home/sale">SALE</a></li>
                <li class="nav-item"><a class="nav-link" href="/web-hotwheels/home/recommended">RECOMMENDED</a></li>
            </ul>

            <div class="d-flex align-items-center">

                <div class="nav-item me-3">
                    <button class="btn nav-link px-2" id="theme-toggle-btn" type="button" title="Chuyển đổi giao diện Sáng/Tối">
                        </button>
                </div>

                <?php if (Session::isLoggedIn()): ?>
                    <div class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Chào, <?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="/web-hotwheels/user/profile">Tài khoản của tôi</a></li>
                            <li><a class="dropdown-item" href="/web-hotwheels/user/orders">Lịch sử đơn hàng</a></li>
                            <li><a class="dropdown-item" href="/web-hotwheels/user/wishlist">Danh sách yêu thích</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="/web-hotwheels/auth/logout">Đăng xuất</a></li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="/web-hotwheels/auth/login" class="nav-link me-3">Đăng nhập/Đăng ký</a>
                <?php endif; ?>

                <a href="/web-hotwheels/cart" class="btn btn-primary ms-2">Giỏ hàng</a>
            </div>
        </div>
    </div>
</nav>

<main class="container my-4"></main>