<?php require_once __DIR__ . '/../../layouts/admin_header.php'; ?>

<h1>Thêm Sản phẩm mới</h1>

<form action="/web-hotwheels/admin/createProduct" method="POST" enctype="multipart/form-data">
    <div class="mb-3">
        <label for="name" class="form-label">Tên sản phẩm</label>
        <input type="text" class="form-control" id="name" name="name" required>
    </div>
    <div class="mb-3">
        <label for="description" class="form-label">Mô tả</label>
        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
    </div>
    <div class="row">
        <div class="col-md-6 mb-3">
            <label for="price" class="form-label">Giá</label>
            <input type="number" class="form-control" id="price" name="price" required>
        </div>
        <div class="col-md-6 mb-3">
            <label for="stock_quantity" class="form-label">Số lượng tồn kho</label>
            <input type="number" class="form-control" id="stock_quantity" name="stock_quantity" required>
        </div>
    </div>
     <div class="mb-3">
        <label for="category_id" class="form-label">Danh mục</label>
        <select class="form-control" id="category_id" name="category_id">
            <option value="1">Hotwheels Premium</option>
            <option value="2">Hotwheels Basic</option>
        </select>
    </div>
    <div class="mb-3">
        <label for="thumbnail" class="form-label">Ảnh đại diện (Thumbnail)</label>
        <input type="file" class="form-control" id="thumbnail" name="thumbnail" accept="image/*">
    </div>
    <button type="submit" class="btn btn-primary">Lưu Sản phẩm</button>
</form>

<?php require_once __DIR__ . '/../../layouts/admin_footer.php'; ?>