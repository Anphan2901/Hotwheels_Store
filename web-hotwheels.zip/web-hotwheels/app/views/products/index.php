<?php require_once __DIR__ . '/../../layouts/admin_header.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1>Quản lý Sản phẩm</h1>
    <a href="/web-hotwheels/admin/createProduct" class="btn btn-primary">Thêm Sản phẩm mới</a>
</div>

<table class="table table-striped table-hover">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tên sản phẩm</th>
            <th>Giá</th>
            <th>Số lượng tồn</th>
            <th>Hành động</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($products as $product): ?>
        <tr>
            <td><?php echo $product->id; ?></td>
            <td><?php echo $product->name; ?></td>
            <td><?php echo number_format($product->price); ?> VNĐ</td>
            <td><?php echo $product->stock_quantity; ?></td>
            <td>
                <a href="/web-hotwheels/admin/editProduct/<?php echo $product->id; ?>" class="btn btn-warning btn-sm">Sửa</a>
                <a href="/web-hotwheels/admin/deleteProduct/<?php echo $product->id; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Bạn chắc chắn muốn xóa?')">Xóa</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php require_once __DIR__ . '/../../layouts/admin_footer.php'; ?>