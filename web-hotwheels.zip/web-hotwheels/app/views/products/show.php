<?php require_once __DIR__ . '/../layouts/main_header.php'; ?>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-7">
            <?php 
                $mainImage = $product->thumbnail ?? 'public/uploads/placeholder.jpg';
                if (!empty($product->images)) {
                    // Ưu tiên ảnh thumbnail nếu có, nếu không thì lấy ảnh đầu tiên
                    foreach($product->images as $img) {
                        if ($img->is_thumbnail) {
                            $mainImage = $img->image_url;
                            break;
                        }
                        $mainImage = $product->images[0]->image_url;
                    }
                }
            ?>
            <img src="/web-hotwheels/<?php echo $mainImage; ?>" class="img-fluid rounded" alt="<?php echo htmlspecialchars($product->name); ?>">
            <?php if (count($product->images) > 1): ?>
                <div class="d-flex mt-2">
                    <?php foreach($product->images as $img): ?>
                        <img src="/web-hotwheels/<?php echo $img->image_url; ?>" style="width: 80px; height: 80px; object-fit: cover; cursor: pointer;" class="img-thumbnail me-2" alt="thumbnail">
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="col-md-5">
            <h1><?php echo htmlspecialchars($product->name); ?></h1>
            <p class="fs-4 fw-bold text-primary"><?php echo number_format((float)$product->price, 0, ',', '.'); ?> VNĐ</p>
            <hr>
            <h4>Mô tả</h4>
            <p><?php echo nl2br(htmlspecialchars($product->description)); ?></p>
            <hr>
            <div class="d-grid gap-2">
                <a href="/web-hotwheels/cart/add/<?php echo $product->id; ?>" class="btn btn-primary btn-lg">Thêm vào giỏ hàng</a>
                <a href="/web-hotwheels/home" class="btn btn-secondary">Quay lại trang chủ</a>
            </div>
        </div>
    </div>

    <div class="row mt-5">
        <div class="col-12">
            <h3>Đánh giá từ khách hàng</h3>
            <?php if(!empty($reviews)): ?>
                <?php foreach($reviews as $review): ?>
                    <div class="card bg-dark mb-3">
                        <div class="card-body">
                            <strong><?php echo htmlspecialchars($review->full_name); ?></strong> - <small class="text-muted"><?php echo date('d/m/Y', strtotime($review->created_at)); ?></small>
                            <p>Đánh giá: <?php echo str_repeat('★', $review->rating) . str_repeat('☆', 5 - $review->rating); ?></p>
                            <p><?php echo nl2br(htmlspecialchars($review->comment)); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Chưa có đánh giá nào cho sản phẩm này.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/main_footer.php'; ?>