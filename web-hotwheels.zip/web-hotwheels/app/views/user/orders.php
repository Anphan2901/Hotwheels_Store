<?php require_once __DIR__ . '/../layouts/main_header.php'; ?>

<h1>Lịch sử đơn hàng của bạn</h1>

<table class="table table-dark table-striped">
    <thead>
        <tr>
            <th>Mã Đơn</th>
            <th>Ngày Đặt</th>
            <th>Tổng Tiền</th>
            <th>Trạng Thái</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($orders as $order): ?>
        <tr>
            <td><?php echo $order->order_code; ?></td>
            <td><?php echo date('d/m/Y', strtotime($order->created_at)); ?></td>
            <td><?php echo number_format($order->total_amount); ?> VNĐ</td>
            <td><span class="badge bg-warning"><?php echo ucfirst($order->status); ?></span></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php require_once __DIR__ . '/../layouts/main_footer.php'; ?>