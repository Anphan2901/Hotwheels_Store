<?php require_once __DIR__ . '/../layouts/main_header.php'; ?>
<div class="row">
    <div class="col-md-3">
        <div class="list-group">
            <a href="/web-hotwheels/user/profile" class="list-group-item list-group-item-action active">Thông tin cá nhân</a>
            <a href="/web-hotwheels/user/orders" class="list-group-item list-group-item-action">Lịch sử đơn hàng</a>
            <a href="/web-hotwheels/user/wishlist" class="list-group-item list-group-item-action">Danh sách yêu thích</a>
            <a href="/web-hotwheels/auth/logout" class="list-group-item list-group-item-action">Đăng xuất</a>
        </div>
    </div>
    <div class="col-md-9">
        <h2>Thông tin cá nhân</h2>
        <form action="/web-hotwheels/user/updateProfile" method="POST">
            <div class="mb-3">
                <label class="form-label">Họ và Tên</label>
                <input type="text" name="full_name" class="form-control" value="<?php echo $user->full_name; ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" class="form-control" value="<?php echo $user->email; ?>" disabled>
            </div>
            <div class="mb-3">
                <label class="form-label">Số điện thoại</label>
                <input type="text" name="phone_number" class="form-control" value="<?php echo $user->phone_number; ?>">
            </div>
            <button type="submit" class="btn btn-primary">Lưu thay đổi</button>
        </form>
    </div>
</div>
<?php require_once __DIR__ . '/../layouts/main_footer.php'; ?>