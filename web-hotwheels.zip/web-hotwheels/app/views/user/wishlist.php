<?php require_once __DIR__ . '/../layouts/main_header.php'; ?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-3">
            <div class="list-group">
                <a href="/web-hotwheels/user/profile" class="list-group-item list-group-item-action">Thông tin cá nhân</a>
                <a href="/web-hotwheels/user/orders" class="list-group-item list-group-item-action">Lịch sử đơn hàng</a>
                <a href="/web-hotwheels/user/wishlist" class="list-group-item list-group-item-action active">Danh sách yêu thích</a>
                <a href="/web-hotwheels/auth/logout" class="list-group-item list-group-item-action">Đăng xuất</a>
            </div>
        </div>

        <div class="col-md-9">
            <h2>Danh sách yêu thích của bạn</h2>
            <hr>
            <div class="row">
                <?php if (!empty($wishlistItems)): ?>
                    <?php foreach ($wishlistItems as $product): ?>
                        <div class="col-md-4 mb-4">
                            <div class="card product-card h-100">
                                <a href="/web-hotwheels/product/show/<?php echo $product->id; ?>" class="text-decoration-none">
                                    <img src="/web-hotwheels/<?php echo (new Product())->getThumb($product->id) ?? 'public/uploads/placeholder.jpg'; ?>" class="card-img-top" alt="<?php echo htmlspecialchars($product->name); ?>">
                                    <div class="card-body">
                                        <h5 class="card-title text-white"><?php echo htmlspecialchars($product->name); ?></h5>
                                    </div>
                                </a>
                                <div class="card-footer bg-transparent border-0 d-flex flex-column">
                                    <p class="card-text fw-bold"><?php echo number_format((float)$product->price, 0, ',', '.'); ?> VNĐ</p>
                                    <div class="mt-auto">
                                         <a href="/web-hotwheels/cart/add/<?php echo $product->id; ?>" class="btn btn-sm btn-primary">Thêm vào giỏ</a>
                                         <a href="#" class="btn btn-sm btn-outline-danger" title="Xóa khỏi danh sách yêu thích">♥</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>Bạn chưa có sản phẩm yêu thích nào.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../layouts/main_footer.php'; ?>