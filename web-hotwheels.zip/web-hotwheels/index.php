<?php

// Bật hiển thị lỗi để gỡ rối
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// --- BẮT ĐẦU KHỐI SỬA LỖI ---
// Kiểm tra nếu chưa có session nào được bắt đầu, thì mới bắt đầu session
// Cách này đảm bảo session_start() chỉ được gọi một lần duy nhất.
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
// --- KẾT THÚC KHỐI SỬA LỖI ---

// Tải cấu hình và các lớp cần thiết
require_once 'app/config/database.php';
require_once 'app/helpers/Session.php';

// Autoload cho Models và Controllers
spl_autoload_register(function ($className) {
    if (file_exists('app/controllers/' . $className . '.php')) {
        require_once 'app/controllers/' . $className . '.php';
    } elseif (file_exists('app/models/' . $className . '.php')) {
        require_once 'app/models/' . $className . '.php';
    }
});

// Phân tích URL
$url = isset($_GET['url']) ? rtrim($_GET['url'], '/') : 'home';
$url = filter_var($url, FILTER_SANITIZE_URL);
$params = explode('/', $url);

// Xác định Controller
$controllerName = !empty($params[0]) ? ucfirst($params[0]) . 'Controller' : 'HomeController';

// Xác định Action (phương thức)
$action = isset($params[1]) ? $params[1] : 'index';

// Xóa controller và action khỏi mảng params
unset($params[0], $params[1]);
$queryParams = array_values($params);

// Kiểm tra và gọi Controller
if (class_exists($controllerName)) {
    $controller = new $controllerName;

    if (method_exists($controller, $action)) {
        call_user_func_array([$controller, $action], $queryParams);
    } else {
        echo "404 - Action Not Found";
    }
} else {
    echo "404 - Controller Not Found: " . $controllerName;
}