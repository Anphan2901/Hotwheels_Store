<?php
// Mật khẩu bạn muốn dùng
$password = 'password123';

// Mã hóa mật khẩu bằng thuật toán mặc định của PHP
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// In ra màn hình để bạn có thể sao chép dễ dàng
echo 'Mật khẩu "password123" đã được mã hóa thành: <br><br>';
echo '<textarea rows="3" cols="70" readonly>' . htmlspecialchars($hashed_password) . '</textarea>';
?>